//
// Decompiled by Jadx - 834ms
//
package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XC_MethodHook;

public class 番茄畅听 implements IXposedHookLoadPackage {
	private ClassLoader classLoader;
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {


if (loadPackageParam.packageName.equals("com.xs.fm"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
XposedHelpers.findAndHookMethod("com.dragon.read.user.d", loadPackageParam.classLoader, "j",XC_MethodReplacement.returnConstant(true));
XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig", loadPackageParam.classLoader, "getAppId",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig$1", loadPackageParam.classLoader, "isPlugin",XC_MethodReplacement.returnConstant("穿山甲"));

    }
    
    
    
});
      
            
}}
	
}