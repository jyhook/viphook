package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import android.content.Context;
import de.robv.android.xposed.XC_MethodHook;

public class 得间小说 implements IXposedHookLoadPackage {
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
if (loadPackageParam.packageName.equals("com.chaozh.iReader.dj"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                XposedHelpers.findAndHookMethod("com.kwad.sdk.core.network.BaseResultData", loadPackageParam.classLoader, "isResultOk",XC_MethodReplacement.returnConstant(false));
                XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig", loadPackageParam.classLoader, "getSdkInfo",XC_MethodReplacement.returnConstant(null));
                XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig", loadPackageParam.classLoader, "getAppId",XC_MethodReplacement.returnConstant(null));
                XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig$1", loadPackageParam.classLoader, "isPlugin",XC_MethodReplacement.returnConstant("穿山甲"));
                XposedHelpers.findAndHookMethod("com.qq.e.comm.managers.b", loadPackageParam.classLoader, "d",XC_MethodReplacement.returnConstant(false));
                XposedHelpers.findAndHookMethod("k5.h", loadPackageParam.classLoader, "i",XC_MethodReplacement.returnConstant(true));
                XposedHelpers.findAndHookMethod("k5.h", loadPackageParam.classLoader, "h",XC_MethodReplacement.returnConstant(360000l));
                                                                          
          }
        }
      );
    }
  }
}