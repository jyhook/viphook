package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import android.content.Context;
import de.robv.android.xposed.XC_MethodHook;

public class VMOS implements IXposedHookLoadPackage {
	private ClassLoader classLoader;
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {


if (loadPackageParam.packageName.equals("com.vmos.pro"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//返回值参数
XposedHelpers.findAndHookMethod("com.cloudinject.feature.̙̙.̗.-$$Lambda$̗̗$rAUXHdbZwvXoqFP2lcPZ1EaoNA8", loadPackageParam.classLoader, "ۣۣۨۧ",Object.class,Object.class,XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.vmos.pro.activities.main.oppo", loadPackageParam.classLoader, "onPostExecute",Object.class,XC_MethodReplacement.returnConstant(null));
          }
        }
      );
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    }
  }
}
                                                
                                                
