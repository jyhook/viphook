package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import android.content.Context;
import de.robv.android.xposed.XC_MethodHook;
import android.view.ViewGroup;
import android.view.View;


public class 星辰视频 implements IXposedHookLoadPackage {

	private ClassLoader classLoader;
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {


if (!loadPackageParam.packageName.equals(null)||loadPackageParam.packageName.equals("com.starmoon.smfilms"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
XposedHelpers.findAndHookMethod("me.goldze.mvvmhabit.http.BaseResponse", loadPackageParam.classLoader, "isOk",XC_MethodReplacement.returnConstant(true));    
XposedHelpers.findAndHookMethod("com.ys.resemble.entity.MineUserInfo", loadPackageParam.classLoader, "getIs_vip",XC_MethodReplacement.returnConstant(1));    
XposedHelpers.findAndHookMethod("com.ys.resemble.entity.MineUserInfo", loadPackageParam.classLoader, "getNickname",XC_MethodReplacement.returnConstant("永久免广告"));    
XposedHelpers.findAndHookMethod("com.ys.resemble.entity.AdInfoDetailEntry", loadPackageParam.classLoader, "getSdk_ad_id",XC_MethodReplacement.returnConstant("穿山甲"));    
XposedHelpers.findAndHookMethod("com.ys.resemble.entity.MineUserInfo", loadPackageParam.classLoader, "getVip_validity",XC_MethodReplacement.returnConstant(218330035200L));    
XposedHelpers.findAndHookMethod("com.ys.resemble.entity.MineUserInfo", loadPackageParam.classLoader, "getInvited_count",XC_MethodReplacement.returnConstant(5201314));    
XposedHelpers.findAndHookMethod("com.ys.resemble.entity.UserInfoEntry", loadPackageParam.classLoader, "getLogin_type",XC_MethodReplacement.returnConstant(1));    
XposedHelpers.findAndHookMethod("com.ys.resemble.ui.homecontent.HomePageViewModel", loadPackageParam.classLoader, "n",XC_MethodReplacement.returnConstant(null));    
XposedHelpers.findAndHookMethod("com.moqi.sdk.utils.i", loadPackageParam.classLoader, "a",Context.class,String.class,String.class,XC_MethodReplacement.returnConstant(null));

                }
            });

            
        }}}
                                                
                                                
