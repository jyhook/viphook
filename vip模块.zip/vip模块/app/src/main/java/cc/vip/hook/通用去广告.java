//无视加固
package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import android.content.Context;
import de.robv.android.xposed.XC_MethodHook;
import android.app.*;

public class 通用去广告 implements IXposedHookLoadPackage {
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
if (!loadPackageParam.packageName.equals(""))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
// 穿山甲
XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig", loadPackageParam.classLoader, "getAppId",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig$1", loadPackageParam.classLoader, "isPlugin",XC_MethodReplacement.returnConstant("穿山甲"));
XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig$1", loadPackageParam.classLoader, "sdkVersionCode",XC_MethodReplacement.returnConstant("穿山甲"));
XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig$1", loadPackageParam.classLoader, "sdkVersionName",XC_MethodReplacement.returnConstant("穿山甲"));
XposedHelpers.findAndHookMethod("com.bytedance.pangle.Zeus", loadPackageParam.classLoader, "hasInit",XC_MethodReplacement.returnConstant(false));
//腾讯广告
XposedHelpers.findAndHookMethod("com.qq.e.ads.rewardvideo.RewardVideoAD", loadPackageParam.classLoader, "loadAD",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.qq.e.ads.rewardvideo.RewardVideoAD", loadPackageParam.classLoader, "showAD",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.qq.e.ads.rewardvideo.RewardVideoAD", loadPackageParam.classLoader, "showAD",Activity.class,XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.qq.e.comm.managers.b", loadPackageParam.classLoader, "d",XC_MethodReplacement.returnConstant(false));
XposedHelpers.findAndHookMethod("com.qq.e.comm.adevent.ADEvent", loadPackageParam.classLoader, "getType",XC_MethodReplacement.returnConstant(1));
XposedHelpers.findAndHookMethod("com.qq.e.comm.constants.CustomPkgConstants", loadPackageParam.classLoader, "getAssetPluginName",XC_MethodReplacement.returnConstant(null));//可能是字符串
XposedHelpers.findAndHookMethod("com.qq.e.comm.constants.CustomPkgConstants", loadPackageParam.classLoader, "getAssetPluginDir",XC_MethodReplacement.returnConstant(null));//可能是字符串
//小米广告
XposedHelpers.findAndHookMethod("com.miui.zeus.mimo.sdk.MimoSdk", loadPackageParam.classLoader, "init",Context.class,"com.miui.zeus.mimo.sdk.MimoSdk$InitCallback",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.miui.zeus.mimo.sdk.MimoSdk", loadPackageParam.classLoader, "setDebugOn",boolean.class,XC_MethodReplacement.returnConstant(null));                                                            
XposedHelpers.findAndHookMethod("com.miui.zeus.mimo.sdk.MimoSdk", loadPackageParam.classLoader, "setStagingOn",boolean.class,XC_MethodReplacement.returnConstant(null));     
//快手
XposedHelpers.findAndHookMethod("com.kwad.sdk.api.loader.v", loadPackageParam.classLoader, "sf",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.kwad.sdk.core.network.BaseResultData", loadPackageParam.classLoader, "hasData",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.kwad.components.offline.api.core.network.model.BaseOfflineCompoResultData", loadPackageParam.classLoader, "hasData",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.kwad.components.offline.api.core.network.adapter.ResultDataAdapter", loadPackageParam.classLoader, "hasData",XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("com.kwad.components.offline.api.core.network.adapter.ResultDataAdapter", loadPackageParam.classLoader, "isResultOk",XC_MethodReplacement.returnConstant(false));
XposedHelpers.findAndHookMethod("com.kwad.components.offline.api.core.network.model.BaseOfflineCompoResultData", loadPackageParam.classLoader, "isResultOk",XC_MethodReplacement.returnConstant(false));
XposedHelpers.findAndHookMethod("com.kwad.sdk.core.network.BaseResultData", loadPackageParam.classLoader, "isResultOk",XC_MethodReplacement.returnConstant(false));
//百度广告
XposedHelpers.findAndHookMethod("com.baidu.mobads.sdk.internal.o", loadPackageParam.classLoader, "a",int.class,XC_MethodReplacement.returnConstant(null));
//迷你世界检测
XposedHelpers.findAndHookMethod("com.tencent.tp.e", loadPackageParam.classLoader, "a",String.class,XC_MethodReplacement.returnConstant(null));                                                       
          }
        }
      );
    }
  }
}
