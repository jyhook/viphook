//
// Decompiled by Jadx - 834ms
//
package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XC_MethodHook;
import android.view.View;
import android.content.Intent;
import android.net.Uri;

public class 番茄小说 implements IXposedHookLoadPackage {
private ClassLoader classLoader;
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {


if (loadPackageParam.packageName.equals("com.dragon.read"))/*包名*/ {
Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
@Override
protected void afterHookedMethod(MethodHookParam param) throws Throwable {
XposedHelpers.findAndHookMethod("com.dragon.read.user.e", loadPackageParam.classLoader, "a",XC_MethodReplacement.returnConstant(true));
XposedHelpers.findAndHookMethod("com.dragon.read.ad.util.d", loadPackageParam.classLoader, "b",XC_MethodReplacement.returnConstant(true));
XposedHelpers.findAndHookMethod("com.bytedance.sdk.openadsdk.TTAdConfig", loadPackageParam.classLoader, "getAppId",XC_MethodReplacement.returnConstant(null));

    }
});



}}
      



}
