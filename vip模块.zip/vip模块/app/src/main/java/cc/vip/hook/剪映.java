//无视加固
package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import android.content.Context;
import de.robv.android.xposed.XC_MethodHook;

public class 剪映 implements IXposedHookLoadPackage {
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
if (loadPackageParam.packageName.equals("com.lemon.lv"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
XposedHelpers.findAndHookMethod("com.lm.components.subscribe.config.UserVipInfo", loadPackageParam.classLoader, "isVipUser",XC_MethodReplacement.returnConstant(true));                                                                                        
XposedHelpers.findAndHookMethod("com.vega.pay.data.VipInfo", loadPackageParam.classLoader, "isVip",XC_MethodReplacement.returnConstant(true));                                                                                        
XposedHelpers.findAndHookMethod("com.vega.pay.data.x30_l", loadPackageParam.classLoader, "isVip",XC_MethodReplacement.returnConstant(true));                                                                                        
XposedHelpers.findAndHookMethod("com.vega.cloud.upload.model.PurchaseInfo", loadPackageParam.classLoader, "getHasPurchased",XC_MethodReplacement.returnConstant(true));                                                                                        
XposedHelpers.findAndHookMethod("com.vega.pay.data.x30_i", loadPackageParam.classLoader, "getHasPurchased",XC_MethodReplacement.returnConstant(true));                                                                                        
          }
        }
      );
    }
  }
}