//
// Decompiled by Jadx - 834ms
//
package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import java.util.List;

public class 酷我音乐 implements IXposedHookLoadPackage {
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
if (loadPackageParam.packageName.equals("cn.kuwo.player"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
        XposedHelpers.findAndHookMethod("cn.kuwo.peculiar.specialinfo.SpecialRealInfo", loadPackageParam.classLoader, "getState",XC_MethodReplacement.returnConstant(1));
        XposedHelpers.findAndHookMethod("cn.kuwo.base.bean.Music", loadPackageParam.classLoader, "isSpPrivilege",XC_MethodReplacement.returnConstant(true));
        XposedHelpers.findAndHookMethod("cn.kuwo.player.activities.EntryActivity", loadPackageParam.classLoader, "isAuthLogin",XC_MethodReplacement.returnConstant(true));
        XposedHelpers.findAndHookMethod("cn.kuwo.peculiar.speciallogic.SceneDialogConf", loadPackageParam.classLoader, "isScene",XC_MethodReplacement.returnConstant(true));
        XposedHelpers.findAndHookMethod("cn.kuwo.peculiar.speciallogic.ConsumptionQueryUtil", loadPackageParam.classLoader, "onwLimited",long.class,List.class,XC_MethodReplacement.returnConstant(true));
        XposedHelpers.findAndHookMethod("cn.kuwo.mod.mobilead.KuwoAdUrl", loadPackageParam.classLoader, "getHost",String.class,XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("cn.kuwo.mod.nowplay.common.BasePlayFragment", loadPackageParam.classLoader,"showMiniAd","cn.kuwo.mod.mobilead.lyricsearchad.LyricAdInfoWrapper",boolean.class,XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("cn.kuwo.mod.mobilead.lyricsearchad.LyricSearchUtils", loadPackageParam.classLoader,"parseAdData",String.class,String.class,"cn.kuwo.mod.mobilead.IAdMgr",XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("cn.kuwo.mod.mobilead.playpagead.PlayPageAdViewController", loadPackageParam.classLoader,"playAd","cn.kuwo.base.bean.Music",XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("cn.kuwo.mod.mobilead.playpagead.PlayPageAdViewController", loadPackageParam.classLoader,"showVideo",ViewGroup.class,XC_MethodReplacement.returnConstant(null));
XposedHelpers.findAndHookMethod("cn.kuwo.mod.theme.detail.star.StarThemeDetailPresenter",loadPackageParam.classLoader,"checkStarThemeFree",XposedHelpers.findClass("cn.kuwo.mod.theme.bean.star.StarTheme", loadPackageParam.classLoader),new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    param.setResult(true);
                }
            });
      XposedHelpers.findAndHookMethod("cn.kuwo.ui.fragment.MainController", loadPackageParam.classLoader, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    ViewGroup viewGroup = (ViewGroup) XposedHelpers.getObjectField(param.thisObject,"mBottomTab");
                    viewGroup.removeViewAt(3);
                    viewGroup.removeViewAt(2);
                    viewGroup.removeViewAt(1);
                }
            }); 
    }
});
}}	
}