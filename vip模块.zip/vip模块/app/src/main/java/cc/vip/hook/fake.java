package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import android.content.Context;
import de.robv.android.xposed.XC_MethodHook;

public class fake implements IXposedHookLoadPackage {
	private ClassLoader classLoader;
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {


if (loadPackageParam.packageName.equals("com.lerist.fakelocation"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {

            XposedHelpers.findAndHookMethod("ށ.ރ.ؠ.ؠ.֏", loadPackageParam.classLoader, "ޅ",XC_MethodReplacement.returnConstant(true));
            XposedHelpers.findAndHookMethod("ށ.ރ.ؠ.ރ.ރ.މ", loadPackageParam.classLoader, "getType",XC_MethodReplacement.returnConstant(1));
            XposedHelpers.findAndHookMethod("ށ.ރ.ؠ.ރ.ރ.މ", loadPackageParam.classLoader, "getProindate",XC_MethodReplacement.returnConstant(4787107805000l));
          }
        }
      );
   
}}}
                                                
                                                
