package cc.vip.hook;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SearchView.OnCloseListener;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.Toast;
import android.view.View;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.Window;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.util.Log;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class MainActivity extends Activity {
private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);
        textView = findViewById(R.id.viphook);
        textView.setText(getInfmation());
        if(getInfmation()!="模块未激活") 
        Toast.makeText(MainActivity.this,"本模块添加Arm Pro注册机，方便后面更新",Toast.LENGTH_SHORT).show();
        }
   
	private String getInfmation() {
	return "模块未激活";
	}
	public void 激活模块(View v) {
	if(getInfmation()=="模块未激活")
	Toast.makeText(MainActivity.this,"在lsposed框架启动模块，点击右上角三个点选择'勾选推荐'",Toast.LENGTH_SHORT).show();
	if(getInfmation()=="模块未激活")
	Toast.makeText(MainActivity.this,"已经激活需要重启vip模块",Toast.LENGTH_SHORT).show();
	if(getInfmation()!="模块未激活")
	下载应用(v);
	}
	public void 通用去广告(View v) {
            final String s="https://www.wjx.cn/vm/OPiXJ3o.aspx#";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}
	public void 加群(View v) {
            final String s="mqqapi://card/show_pslcard?src_type=internal&version=1&uin=204513769&card_type=group&source=qrcode";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}
	public void 关于(View v) {
AlertDialog dialog=new AlertDialog.Builder(this)
.setTitle("关于")
.setMessage("内容")
.setPositiveButton("确定", new DialogInterface.OnClickListener() {

@Override
public void onClick(DialogInterface dialog, int which){

}
})
.setNegativeButton("取消", null)
.create();
dialog.show();
	}
	public void 投稿(View v) {
            final String s="https://www.wjx.cn/vm/Y7X0FAo.aspx#";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}
	public void 打赏(View v) {
            final String s="http://wp.yyds666.fun/";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}
	public void 下载应用(View v) {
	Toast.makeText(MainActivity.this,"密码:6666",Toast.LENGTH_SHORT).show();
            final String s="https://wwd.lanzoui.com/b03pa7ceh";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}

	public void 野马视频(View v) {
            final String s="https://xz.zelark.com/ldy/share/index.html?app_id=banma&code=CBE9F4&type=share";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 番茄小说(View v) {
            final String s="market://details?id=com.dragon.read";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 番茄畅听(View v) {
            final String s="market://details?id=com.xs.fm";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 万能钥匙(View v) {
            final String s="market://details?id=com.snda.wifilocating";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 星辰视频(View v) {
            final String s="http://vp1.kthtea.com.cn/channel/html?page=S9HM2FYEZV&invited_by=19353705";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 腾讯微云(View v) {
            final String s="market://details?id=com.qq.qcloud";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 绿去广告(View v) {
            final String s="market://details?id=com.auto.greenskipad";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 酷我音乐(View v) {
            final String s="https://share.weiyun.com/HhOi1P76";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void VMOS(View v) {
	Toast.makeText(MainActivity.this,"密码:6666",Toast.LENGTH_SHORT).show();
            final String s="https://wwei.lanzoui.com/inxjM0hw2zna";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void fake(View v) {
            final String s="http://fakeloc.cc/app";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 免费小说(View v) {
            final String s="http://api.fantuants.com/fantuanbbs/invite/ivt/B7BJRn?type=0";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 得间小说(View v) {
            final String s="market://details?id=com.chaozh.iReader.dj";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void 剪映(View v) {
	Toast.makeText(MainActivity.this,"密码:6666",Toast.LENGTH_SHORT).show();
            final String s="https://wwei.lanzoui.com/ibBpo0hxxx3a";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
	public void vpn(View v) {
	Toast.makeText(MainActivity.this,"密码:6666",Toast.LENGTH_SHORT).show();
            final String s="https://wwei.lanzoui.com/b03plq52d";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(s)));
	}	
 
 
 

 
    
 

                                                     

}
