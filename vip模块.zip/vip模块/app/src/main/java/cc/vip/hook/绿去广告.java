package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import android.content.Context;
import de.robv.android.xposed.XC_MethodHook;

public class 绿去广告 implements IXposedHookLoadPackage {
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {

if (loadPackageParam.packageName.equals("com.auto.greenskipad"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                XposedHelpers.findAndHookMethod("h.a.a.h.b", loadPackageParam.classLoader, "a",XC_MethodReplacement.returnConstant(true));
                XposedHelpers.findAndHookMethod("h.a.a.h.b", loadPackageParam.classLoader, "b",XC_MethodReplacement.returnConstant(true));
          }
        }
      );
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    }
  }
}
                                                
                                                
