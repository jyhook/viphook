package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XC_MethodHook;
import android.content.*;
import android.widget.*;
import android.app.Activity;
import android.view.*;
import android.net.*;


public class 野马视频 implements IXposedHookLoadPackage {
        	private ClassLoader classLoader;
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {


if (!loadPackageParam.packageName.equals(null)||loadPackageParam.packageName.equals("com.zhpphls.banma"))/*包名*/ {
            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {

        XposedHelpers.findAndHookMethod("com.newfroyobt.comentity.UserInfo", loadPackageParam.classLoader, "getFree_time",XC_MethodReplacement.returnConstant(218330035200l));
        XposedHelpers.findAndHookMethod("com.newfroyobt.comentity.AdResp", loadPackageParam.classLoader, "getAdspos",XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("com.newfroyobt.comentity.AdResp", loadPackageParam.classLoader, "getAdsconf",XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("com.moqi.sdk.utils.i$a", loadPackageParam.classLoader, "run",XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("com.newfroyobt.comentity.SysConfigBean", loadPackageParam.classLoader, "getUpgrade_info",XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("com.newfroyobt.comentity.UserInfo", loadPackageParam.classLoader, "getInvited_count",XC_MethodReplacement.returnConstant(6666));
        XposedHelpers.findAndHookMethod("com.newfroyobt.comentity.UserInfo", loadPackageParam.classLoader, "getLogin_type",XC_MethodReplacement.returnConstant(0));
        XposedHelpers.findAndHookMethod("com.newfroyobt.comentity.UserInfo", loadPackageParam.classLoader, "getNickname",XC_MethodReplacement.returnConstant("5.0.1版去广告"));
        XposedHelpers.findAndHookMethod("com.newfroyobt.comentity.SysConf", loadPackageParam.classLoader, "getFilm_notice",XC_MethodReplacement.returnConstant("加群:204513769获取最新模块或者催更新"));
        XposedHelpers.findAndHookMethod("b.k.a.b.b$a", loadPackageParam.classLoader, "onClick",View.class,XC_MethodReplacement.returnConstant(null));
        XposedHelpers.findAndHookMethod("b.c.a.b.f", loadPackageParam.classLoader, "a",CharSequence.class,XC_MethodReplacement.returnConstant(null));
            
    
};
      
            
});
	
}}}
