//
// Decompiled by Jadx - 834ms
//
package cc.vip.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import android.content.Context;
import de.robv.android.xposed.XC_MethodHook;
import android.view.*;
import android.widget.*;
import android.widget.TextView;
import java.util.*;
import java.lang.Object;
public class 免费小说 implements IXposedHookLoadPackage
{

public void handleLoadPackage ( final XC_LoadPackage.LoadPackageParam loadPackageParam ) throws Throwable
{
				
if ( loadPackageParam.packageName.equals ( "com.fantuanqwmfxsjuqian" ) )
/*包名*/ {
Class ActivityThread = XposedHelpers.findClass ( "android.app.ActivityThread",/*这里不用改*/loadPackageParam.classLoader );
XposedBridge.hookAllMethods ( ActivityThread, "performLaunchActivity",/*这里不用改*/new XC_MethodHook ( ) {
@Override
protected void afterHookedMethod ( MethodHookParam param ) throws Throwable
{
XposedHelpers.findAndHookMethod("com.fantuantanshujbk.bookshelf.ui.activity.NovelReaderActivity", loadPackageParam.classLoader,"onClick",View.class,XC_MethodReplacement.returnConstant(null));


XposedHelpers.findAndHookMethod("com.fantuantanshujbk.common.loading.ui.LoadingActivity", loadPackageParam.classLoader, "getGeneralAdContainerGroup", new XC_MethodHook() {
@Override
protected void afterHookedMethod(MethodHookParam param) throws Throwable {
param.setResult(null);
}
}); 
XposedHelpers.findAndHookMethod("com.qq.e.comm.managers.GDTADManager", loadPackageParam.classLoader, "isInitialized", new XC_MethodHook() {
@Override
protected void afterHookedMethod(MethodHookParam param) throws Throwable {
param.setResult(false);
}
}); 

XposedHelpers.findAndHookMethod("com.fantuantanshujbk.common.framework.cache.ConfigSharedPreferences", loadPackageParam.classLoader, "isNewUserAdFreeTimeFinish",XC_MethodReplacement.returnConstant(false));
// XposedHelpers.findAndHookMethod("com.fantuantanshujbk.me.manager.UCManager", loadPackageParam.classLoader, "isLogin",XC_MethodReplacement.returnConstant(false));
XposedHelpers.findAndHookMethod("com.fantuantanshujbk.me.mapping.PersonalInfo", loadPackageParam.classLoader, "getCreateTime",XC_MethodReplacement.returnConstant(66355200000000l));            
XposedHelpers.findAndHookMethod("com.fantuantanshujbk.common.manager.AdFreeManager", loadPackageParam.classLoader, "addOfflineAdFreeDuration",long.class ,new XC_MethodHook() {
@Override
protected void afterHookedMethod(MethodHookParam param) throws Throwable {
super.afterHookedMethod(param);

}
});

}} );}}}
